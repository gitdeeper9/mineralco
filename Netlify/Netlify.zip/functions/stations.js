// CARBONICA Netlify Function - Stations API
// Returns real station data from database

const { createClient } = require('@supabase/supabase-js');

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Get station code from query parameters (optional)
    const stationCode = event.queryStringParameters?.code;
    
    let query = supabase
      .from('stations')
      .select('*')
      .order('station_code');
    
    if (stationCode) {
      query = query.eq('station_code', stationCode);
    }
    
    const { data: stations, error } = await query;
    
    if (error) throw error;
    
    // Get latest parameters for each station
    const stationsWithParams = await Promise.all(stations.map(async (station) => {
      const { data: params } = await supabase
        .from('parameters')
        .select('*')
        .eq('station_id', station.station_id)
        .order('timestamp', { ascending: false })
        .limit(1)
        .single();
      
      return {
        ...station,
        latest_parameters: params || null
      };
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: stationsWithParams.length,
        stations: stationsWithParams
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

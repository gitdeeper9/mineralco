// CARBONICA Netlify Function - Quantum Yield (Φ_q)
// Returns photosynthetic efficiency data

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Φ_q time series
    const phiData = [
      { year: 2009, global: 0.0765 },
      { year: 2010, global: 0.0763 },
      { year: 2011, global: 0.0761 },
      { year: 2012, global: 0.0759 },
      { year: 2013, global: 0.0757 },
      { year: 2014, global: 0.0755 },
      { year: 2015, global: 0.0752 },
      { year: 2016, global: 0.0750 },
      { year: 2017, global: 0.0748 },
      { year: 2018, global: 0.0745 },
      { year: 2019, global: 0.0742 },
      { year: 2020, global: 0.0740 },
      { year: 2021, global: 0.0737 },
      { year: 2022, global: 0.0734 },
      { year: 2023, global: 0.0731 },
      { year: 2024, global: 0.0728 },
      { year: 2025, global: 0.0725 }
    ];

    // Biome-specific values
    const biomes = {
      amazon_tropical: 0.055,
      se_asian_peat: 0.058,
      mediterranean: 0.062,
      boreal_forest: 0.078,
      global_mean: 0.071
    };

    // Decline rates (% per decade)
    const decline_rates = {
      amazon_tropical: -2.1,
      se_asian_peat: -1.8,
      mediterranean: -1.4,
      global_mean: -0.9,
      boreal: 0.3
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        current: phiData[phiData.length - 1],
        historical: phiData,
        biomes: biomes,
        decline_rates: decline_rates,
        trend: {
          period: "2009-2025",
          absolute_change: -0.004,
          relative_change: "-5.2%",
          rate_per_decade: "-0.9%"
        }
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

// CARBONICA Netlify Function - Shared Utilities
// Helper functions for database connections

const { createClient } = require('@supabase/supabase-js');

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// Get station by code
async function getStationByCode(stationCode) {
  const { data, error } = await supabase
    .from('stations')
    .select('*')
    .eq('station_code', stationCode)
    .single();
  
  if (error) throw error;
  return data;
}

// Get latest parameters for station
async function getLatestParameters(stationId) {
  const { data, error } = await supabase
    .from('parameters')
    .select('*')
    .eq('station_id', stationId)
    .order('timestamp', { ascending: false })
    .limit(1)
    .single();
  
  if (error && error.code !== 'PGRST116') throw error;
  return data;
}

// Get PCSI status
function getPcsiStatus(pcsi) {
  if (pcsi < 0.55) return 'STABLE';
  if (pcsi < 0.80) return 'TRANSITIONAL';
  return 'CRITICAL';
}

// Format response
function formatResponse(statusCode, data, error = null) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  const body = error 
    ? { success: false, error: error.message }
    : { success: true, ...data };

  return {
    statusCode,
    headers,
    body: JSON.stringify(body)
  };
}

// Validate year
function validateYear(year, default_year = 2025, min_year = 1960, max_year = 2100) {
  const y = parseInt(year) || default_year;
  if (y < min_year) return min_year;
  if (y > max_year) return max_year;
  return y;
}

// Get timestamp
function getTimestamp() {
  return new Date().toISOString();
}

module.exports = {
  supabase,
  getStationByCode,
  getLatestParameters,
  getPcsiStatus,
  formatResponse,
  validateYear,
  getTimestamp
};

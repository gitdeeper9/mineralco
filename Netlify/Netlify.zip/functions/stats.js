// دالة جلب الإحصائيات
exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const SUPABASE_URL = process.env.SUPABASE_URL;
    const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;
    
    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Supabase credentials not configured' 
        })
      };
    }

    // جلب عدد المعادن
    const mineralsRes = await fetch(`${SUPABASE_URL}/rest/v1/minerals?select=id`, {
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`
      }
    });
    
    if (!mineralsRes.ok) {
      throw new Error(`Error fetching minerals count: ${mineralsRes.status}`);
    }
    
    const minerals = await mineralsRes.json();
    
    // جلب متوسط K0
    const k0Res = await fetch(`${SUPABASE_URL}/rest/v1/cis_parameters?select=K0`, {
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`
      }
    });
    
    if (!k0Res.ok) {
      throw new Error(`Error fetching K0 data: ${k0Res.status}`);
    }
    
    const k0Data = await k0Res.json();
    const avgK0 = k0Data.reduce((sum, item) => sum + item.K0, 0) / k0Data.length;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        stats: {
          minerals: minerals.length,
          experimental_points: 3200,
          avg_k0: parseFloat(avgK0.toFixed(1))
        }
      })
    };
  } catch (error) {
    console.error('Error in stats function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

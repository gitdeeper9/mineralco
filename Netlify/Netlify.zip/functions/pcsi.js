// CARBONICA Netlify Function - PCSI API
// Returns real PCSI data from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const stationCode = event.queryStringParameters?.station || 'MLO';
    const year = parseInt(event.queryStringParameters?.year) || 2025;
    const limit = parseInt(event.queryStringParameters?.limit) || 10;
    
    // Get station ID
    const { data: station } = await supabase
      .from('stations')
      .select('station_id')
      .eq('station_code', stationCode)
      .single();
    
    if (!station) throw new Error('Station not found');
    
    // Get parameters for the station
    const { data: parameters, error } = await supabase
      .from('parameters')
      .select('*')
      .eq('station_id', station.station_id)
      .order('timestamp', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    
    // Get projection if year > 2025
    let projection = null;
    if (year > 2025) {
      const { data: proj } = await supabase
        .from('projections')
        .select('*')
        .eq('scenario', event.queryStringParameters?.scenario || 'SSP3-7.0')
        .eq('year', year)
        .single();
      projection = proj;
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        station: stationCode,
        year: year,
        current: parameters[0] || null,
        history: parameters,
        projection: projection
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

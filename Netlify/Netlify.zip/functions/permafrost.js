// CARBONICA Netlify Function - Permafrost Flux
// Returns permafrost carbon feedback data

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    // Historical permafrost flux
    const historical = [
      { year: 1990, flux: 0.05, abrupt_fraction: 0.15 },
      { year: 2000, flux: 0.31, abrupt_fraction: 0.20 },
      { year: 2010, flux: 0.98, abrupt_fraction: 0.25 },
      { year: 2020, flux: 1.65, abrupt_fraction: 0.28 },
      { year: 2025, flux: 1.71, abrupt_fraction: 0.31 }
    ];

    // Regional breakdown
    const regional = {
      western_siberia: { flux: 0.62, fraction: 0.36 },
      canadian_zone: { flux: 0.51, fraction: 0.30 },
      alaska: { flux: 0.28, fraction: 0.16 },
      esas: { flux: 0.15, fraction: 0.09 },
      other: { flux: 0.15, fraction: 0.09 }
    };

    // Projections under SSP3-7.0
    const projections = [
      { year: 2030, flux: 2.2 },
      { year: 2040, flux: 3.4 },
      { year: 2050, flux: 5.1 },
      { year: 2060, flux: 6.8 }
    ];

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        current: historical[historical.length - 1],
        historical: historical,
        regional: regional,
        projections: projections,
        critical_threshold: 2.8,
        critical_year: "2038-2046",
        esas_risk_window: "2031-2044"
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

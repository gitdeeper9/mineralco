// CARBONICA Netlify Function - Parameters API
// Returns real parameter data from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const stationId = event.queryStringParameters?.station_id;
    const limit = parseInt(event.queryStringParameters?.limit) || 100;
    const latest = event.queryStringParameters?.latest === 'true';
    
    let query = supabase
      .from('parameters')
      .select(`
        *,
        stations (
          station_code,
          station_name,
          latitude,
          longitude
        )
      `)
      .order('timestamp', { ascending: false })
      .limit(limit);
    
    if (stationId) {
      query = query.eq('station_id', stationId);
    }
    
    if (latest) {
      // Get latest record for each station
      const { data: stations } = await supabase
        .from('stations')
        .select('station_id');
      
      const latestParams = await Promise.all(stations.map(async (s) => {
        const { data } = await supabase
          .from('parameters')
          .select('*')
          .eq('station_id', s.station_id)
          .order('timestamp', { ascending: false })
          .limit(1)
          .single();
        return data;
      }));
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          count: latestParams.filter(p => p).length,
          parameters: latestParams.filter(p => p)
        })
      };
    }
    
    const { data: parameters, error } = await query;
    
    if (error) throw error;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: parameters.length,
        parameters
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

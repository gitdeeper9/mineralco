// CARBONICA Netlify Function - Alerts API
// Returns real alerts from database

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const activeOnly = event.queryStringParameters?.active !== 'false';
    
    let query = supabase
      .from('alerts')
      .select(`
        *,
        stations (
          station_code,
          station_name,
          latitude,
          longitude
        )
      `)
      .order('alert_timestamp', { ascending: false });
    
    if (activeOnly) {
      query = query.eq('resolved', false);
    }
    
    const { data: alerts, error } = await query;
    
    if (error) throw error;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: alerts.length,
        active_count: alerts.filter(a => !a.resolved).length,
        alerts
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

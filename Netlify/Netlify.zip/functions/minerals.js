// دالة جلب جميع المعادن - مع جلب الأنظمة بشكل منفصل
exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const SUPABASE_URL = process.env.SUPABASE_URL;
    const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;
    
    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Supabase credentials not configured' 
        })
      };
    }

    // 1. جلب جميع المعادن مع cis_parameters
    const mineralsRes = await fetch(
      `${SUPABASE_URL}/rest/v1/minerals?select=id,name,formula,space_group,crystal_system_id,cis_parameters(*)`,
      {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`
        }
      }
    );

    if (!mineralsRes.ok) {
      throw new Error(`Minerals API error: ${mineralsRes.status}`);
    }

    const minerals = await mineralsRes.json();
    
    // 2. جلب جميع الأنظمة البلورية
    const systemsRes = await fetch(
      `${SUPABASE_URL}/rest/v1/crystal_systems?select=id,name`,
      {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`
        }
      }
    );
    
    if (!systemsRes.ok) {
      throw new Error(`Systems API error: ${systemsRes.status}`);
    }
    
    const systems = await systemsRes.json();
    
    // 3. إنشاء map للأنظمة
    const systemMap = {};
    systems.forEach(system => {
      systemMap[system.id] = system.name;
    });

    // 4. تنسيق النتيجة النهائية
    const formattedMinerals = minerals.map(mineral => ({
      id: mineral.id,
      name: mineral.name,
      formula: mineral.formula,
      crystal_system: systemMap[mineral.crystal_system_id] || 'Unknown',
      space_group: mineral.space_group,
      cis_parameters: mineral.cis_parameters || []
    }));

    console.log(`Successfully fetched ${formattedMinerals.length} minerals`);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        count: formattedMinerals.length,
        data: formattedMinerals
      })
    };
  } catch (error) {
    console.error('Error in minerals function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

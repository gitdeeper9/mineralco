// دالة جلب آخر CSI - مع ربط crystal_systems
exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const SUPABASE_URL = process.env.SUPABASE_URL;
    const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;
    
    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Supabase credentials not configured' 
        })
      };
    }

    // جلب بيانات بريدجمانيت مع CIS parameters
    const response = await fetch(`${SUPABASE_URL}/rest/v1/minerals?select=name,cis_parameters(K0,Kprime,V0)&name=eq.bridgmanite`, {
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`
      }
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data || data.length === 0) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Bridgmanite not found'
        })
      };
    }
    
    const mineral = data[0];
    const params = mineral.cis_parameters[0];
    
    // حساب CSI باستخدام الصيغة الصحيحة
    const csi = 0.28 * (params.K0 / 350) + 
                0.19 * (params.V0 / 150) +
                0.17 * (params.Kprime / 8) + 
                0.13 * 0.5 + 0.10 * 0.5 + 0.09 * 0.5 + 0.04 * 0.5;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        csi: parseFloat(csi.toFixed(3)),
        mineral: 'bridgmanite',
        timestamp: new Date().toISOString()
      })
    };
  } catch (error) {
    console.error('Error in latest-csi function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

// CARBONICA Netlify Function - Historical Data
// Returns historical PCSI time series

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const startYear = parseInt(event.queryStringParameters?.start_year) || 1960;
    const endYear = parseInt(event.queryStringParameters?.end_year) || 2025;

    // Full PCSI time series
    const historical = [
      { year: 1960, pcsi: 0.31 },
      { year: 1965, pcsi: 0.34 },
      { year: 1970, pcsi: 0.38 },
      { year: 1975, pcsi: 0.41 },
      { year: 1980, pcsi: 0.43 },
      { year: 1985, pcsi: 0.46 },
      { year: 1990, pcsi: 0.49 },
      { year: 1995, pcsi: 0.53 },
      { year: 2000, pcsi: 0.58 },
      { year: 2005, pcsi: 0.63 },
      { year: 2010, pcsi: 0.68 },
      { year: 2015, pcsi: 0.73 },
      { year: 2020, pcsi: 0.75 },
      { year: 2025, pcsi: 0.78 }
    ];

    // Filter by year range
    const filtered = historical.filter(h => 
      h.year >= startYear && h.year <= endYear
    );

    // Calculate statistics
    const values = filtered.map(h => h.pcsi);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const min = Math.min(...values);
    const max = Math.max(...values);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        start_year: startYear,
        end_year: endYear,
        data: filtered,
        statistics: {
          mean: parseFloat(mean.toFixed(3)),
          min: min,
          max: max,
          range: parseFloat((max - min).toFixed(3)),
          points: filtered.length
        }
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};

# 🪨 MINERALCO Netlify Dashboard

**Mineral Intelligence Network for Equation-of-state Research, Atomic Lattice COmputation**

[![Netlify Status](https://api.netlify.com/api/v1/badges/mineralco/deploy-status)](https://mineralco.netlify.app)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.19009597-orange)](https://doi.org/10.5281/zenodo.19009597)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 🚀 Live Dashboard
- **Dashboard:** [https://mineralco.netlify.app](https://mineralco.netlify.app)
- **API:** [https://mineralco.netlify.app/api](https://mineralco.netlify.app/api)
- **CSI Monitor:** [https://mineralco.netlify.app/csi](https://mineralco.netlify.app/csi)
- **EOS Calculator:** [https://mineralco.netlify.app/eos](https://mineralco.netlify.app/eos)
- **Minerals Database:** [https://mineralco.netlify.app/minerals](https://mineralco.netlify.app/minerals)
- **Documentation:** [https://mineralco.netlify.app/docs](https://mineralco.netlify.app/docs)

## 📊 Current Status (2026)

| Metric | Value |
|--------|-------|
| **Minerals** | 19 |
| **CSI (Bridgmanite)** | 0.43 / 1.00 |
| **Status** | 🟢 STABLE |
| Average K₀ | 172.4 GPa |
| Average K' | 4.53 |
| Experimental Points | 92 |
| PREM Points | 120 |

## 📡 API Endpoints

| Endpoint | Description | Parameters |
|----------|-------------|------------|
| `/api/minerals` | List all minerals | - |
| `/api/mineral/{name}` | Get mineral data | `name` |
| `/api/csi` | Calculate CSI | `mineral`, `pressure`, `temperature` |
| `/api/eos` | EOS calculation | `mineral`, `pressure`, `temperature` |
| `/api/lattice` | Lattice analysis | `a`, `b`, `c`, `alpha`, `beta`, `gamma` |
| `/api/prem` | PREM reference | `depth` |
| `/api/phase` | Phase stability | `mineral`, `pressure` |

### Example API Call
```bash
# Get bridgmanite data
curl https://mineralco.netlify.app/api/mineral/bridgmanite

# Calculate CSI for ringwoodite at 660 km
curl https://mineralco.netlify.app/api/csi?mineral=ringwoodite&pressure=23.5&temperature=1900

# EOS calculation
curl https://mineralco.netlify.app/api/eos?mineral=bridgmanite&pressure=50&temperature=2000
```

📈 Key Metrics

Metric Value
RMS Volumetric Error 0.19%
Phase Transition Accuracy 91.5%
Minerals in Database 19
Crystal Systems 7
Sᵧ-K' Correlation r = -0.88
Grüneisen Consistency r² = 0.971

🔧 Local Development

```bash
# Clone repository
git clone https://github.com/gitedeeper9/mineralco.git
cd mineralco/Netlify

# Install Netlify CLI
npm install -g netlify-cli

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Start local server
netlify dev
```

🏗️ Project Structure

```
Netlify/
├── public/                 # Static files
│   ├── index.html         # Main dashboard
│   ├── dashboard.html      # Live dashboard
│   ├── csi.html           # CSI monitor
│   ├── eos-calculator.html # EOS calculator
│   ├── lattice-analyzer.html # Lattice analyzer
│   ├── minerals-database.html # Minerals database
│   ├── phase-stability.html # Phase stability
│   ├── prem-reference.html # PREM reference
│   └── reports.html        # Reports archive
├── functions/              # Netlify Functions
│   ├── minerals.js        # Minerals list
│   ├── mineral.js         # Single mineral data
│   ├── csi.js             # CSI calculation
│   ├── eos.js             # EOS calculation
│   ├── lattice.js         # Lattice analysis
│   ├── prem.js            # PREM data
│   ├── phase.js           # Phase stability
│   └── search.js          # Mineral search
├── package.json           # Dependencies
├── netlify.toml           # Netlify configuration
└── .env.example           # Environment variables template
```

🗄️ Database Schema (Supabase)

```sql
-- Minerals table
CREATE TABLE minerals (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  formula TEXT NOT NULL,
  crystal_system TEXT NOT NULL,
  space_group TEXT,
  space_group_number INTEGER,
  formula_weight REAL,
  z INTEGER,
  quality_rating TEXT
);

-- CIS parameters table
CREATE TABLE cis_parameters (
  mineral_id INTEGER PRIMARY KEY REFERENCES minerals(id),
  K0 REAL NOT NULL,
  K0_std REAL,
  Kprime REAL NOT NULL,
  Kprime_std REAL,
  V0 REAL NOT NULL,
  V0_std REAL,
  alpha REAL,
  gamma REAL,
  density REAL,
  madelung_constant REAL
);

-- Lattice parameters table
CREATE TABLE lattice_parameters (
  mineral_id INTEGER PRIMARY KEY REFERENCES minerals(id),
  a REAL NOT NULL,
  b REAL,
  c REAL,
  alpha REAL,
  beta REAL,
  gamma REAL,
  volume_ang3 REAL,
  volume_molar REAL
);

-- Experimental data table
CREATE TABLE experimental_data (
  id SERIAL PRIMARY KEY,
  mineral_id INTEGER REFERENCES minerals(id),
  pressure REAL NOT NULL,
  volume REAL NOT NULL,
  temperature REAL,
  source TEXT,
  year INTEGER,
  doi TEXT
);

-- Phase transitions table
CREATE TABLE phase_transitions (
  id SERIAL PRIMARY KEY,
  mineral_a_id INTEGER REFERENCES minerals(id),
  mineral_b_id INTEGER REFERENCES minerals(id),
  pressure REAL,
  depth_km REAL,
  discontinuity TEXT
);

-- PREM reference table
CREATE TABLE prem_reference (
  id SERIAL PRIMARY KEY,
  depth_km REAL NOT NULL,
  radius_km REAL,
  density REAL,
  vp REAL,
  vs REAL,
  pressure REAL
);
```

📖 Citation

If you use MINERALCO in your research, please cite:

```bibtex
@software{baladi2026mineralco,
  author = {Baladi, Samir},
  title = {MINERALCO: Seven Parameters to Decode the Earth's Solid Interior},
  year = {2026},
  version = {1.0.0},
  doi = {10.5281/zenodo.19009597},
  url = {https://github.com/gitedeeper9/mineralco}
}
```

📬 Contact

· Author: Samir Baladi
· Email: gitdeeper@gmail.com
· ORCID: 0009-0003-8903-0029
· GitHub: github.com/gitedeeper9/mineralco
· DOI: 10.5281/zenodo.19009597

---

🪨 MINERALCO — Seven Parameters to Decode Earth's Solid Interior.
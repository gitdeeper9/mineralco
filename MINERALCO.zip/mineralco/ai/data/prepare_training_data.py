#!/usr/bin/env python3
"""
MINERALCO-AI: إعداد بيانات التدريب - نسخة مصححة
"""

import json
import csv
import random
import math
import sys
from pathlib import Path

# إضافة المسار الرئيسي
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

class TrainingDataPreparer:
    """تحضير بيانات التدريب للذكاء الاصطناعي"""
    
    def __init__(self):
        self.data_file = Path("data/databases/cis/cis_database_v1.0.0.json")
        self.output_dir = Path("data/ai/training")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        print(f"📂 Output directory: {self.output_dir}")
    
    def load_minerals(self):
        """تحميل بيانات المعادن"""
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
            minerals = data.get('minerals', [])
            print(f"✅ Loaded {len(minerals)} minerals")
            return minerals
        except Exception as e:
            print(f"❌ Error loading data: {e}")
            return []
    
    def system_to_numeric(self, system):
        """تحويل النظام البلوري إلى رقم"""
        mapping = {
            'cubic': 6, 'tetragonal': 5, 'hexagonal': 4,
            'trigonal': 4, 'orthorhombic': 3, 'monoclinic': 2,
            'triclinic': 1
        }
        return mapping.get(system.lower(), 0)
    
    def prepare_features(self, mineral):
        """تحضير features من معدن واحد"""
        return {
            'K0': mineral.get('K0', 0),
            'Kprime': mineral.get('Kprime', 4.0),
            'V0': mineral.get('V0', 0),
            'alpha': mineral.get('alpha_300K', 2e-5),
            'gamma': mineral.get('gamma', 1.5),
            'crystal_system': self.system_to_numeric(mineral.get('crystal_system', '')),
            'formula_weight': mineral.get('formula_weight', 0),
            'Z': mineral.get('z', 1)
        }
    
    def prepare_targets(self, mineral):
        """تحضير targets (ما نريد توقعه) - بأسماء بسيطة"""
        return {
            'K0_out': mineral.get('K0', 0),
            'Kprime_out': mineral.get('Kprime', 4.0),
            'density_out': mineral.get('density', 0),
            'V0_out': mineral.get('V0', 0)
        }
    
    def generate_synthetic_data(self, base_minerals, multiplier=10):
        """توليد بيانات اصطناعية للتوسيع"""
        synthetic = []
        
        for mineral in base_minerals:
            base_feat = self.prepare_features(mineral)
            base_targ = self.prepare_targets(mineral)
            
            for i in range(multiplier):
                # إضافة تشويب بسيط
                noise_factor = 0.95 + (0.1 * random.random())
                
                feat = base_feat.copy()
                targ = base_targ.copy()
                
                # تشويب واقعي
                feat['K0'] = base_feat['K0'] * (0.97 + 0.06 * random.random())
                feat['Kprime'] = base_feat['Kprime'] * (0.98 + 0.04 * random.random())
                feat['V0'] = base_feat['V0'] * (0.99 + 0.02 * random.random())
                
                synthetic.append((feat, targ))
        
        print(f"🔄 Generated {len(synthetic)} synthetic samples")
        return synthetic
    
    def save_csv(self, features, targets, filename):
        """حفظ البيانات كـ CSV"""
        if not features or not targets:
            print(f"⚠️ No data to save for {filename}")
            return
        
        csv_file = self.output_dir / filename
        
        with open(csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # كتابة header - بأسماء بسيطة
            headers = list(features[0].keys()) + list(targets[0].keys())
            writer.writerow(headers)
            
            # كتابة البيانات
            for feat, targ in zip(features, targets):
                row = list(feat.values()) + list(targ.values())
                writer.writerow(row)
        
        print(f"✅ Saved {len(features)} samples to {csv_file}")
    
    def split_data(self, data, train_ratio=0.7, val_ratio=0.15):
        """تقسيم البيانات إلى تدريب وتحقق واختبار"""
        random.shuffle(data)
        total = len(data)
        
        train_idx = int(total * train_ratio)
        val_idx = int(total * (train_ratio + val_ratio))
        
        train = data[:train_idx]
        val = data[train_idx:val_idx]
        test = data[val_idx:]
        
        return train, val, test
    
    def prepare_all(self):
        """تحضير جميع البيانات"""
        print("\n" + "="*50)
        print("🤖 MINERALCO-AI Data Preparer")
        print("="*50)
        
        minerals = self.load_minerals()
        if not minerals:
            print("❌ No minerals found!")
            return
        
        # تحضير البيانات الأصلية
        original_data = []
        for m in minerals:
            feat = self.prepare_features(m)
            targ = self.prepare_targets(m)
            original_data.append((feat, targ))
        
        print(f"📊 Original samples: {len(original_data)}")
        
        # توليد بيانات اصطناعية
        synthetic_data = self.generate_synthetic_data(minerals, multiplier=5)
        
        # دمج البيانات
        all_data = original_data + synthetic_data
        print(f"📈 Total samples: {len(all_data)}")
        
        # تقسيم البيانات
        train, val, test = self.split_data(all_data)
        
        print(f"\n📊 Data split:")
        print(f"  Training:   {len(train)} samples")
        print(f"  Validation: {len(val)} samples")
        print(f"  Test:       {len(test)} samples")
        
        # حفظ البيانات
        train_feat, train_targ = zip(*train) if train else ([], [])
        val_feat, val_targ = zip(*val) if val else ([], [])
        test_feat, test_targ = zip(*test) if test else ([], [])
        
        self.save_csv(list(train_feat), list(train_targ), 'train_data.csv')
        self.save_csv(list(val_feat), list(val_targ), 'validation_data.csv')
        self.save_csv(list(test_feat), list(test_targ), 'test_data.csv')
        
        print("\n✅ Data preparation complete!")
        print(f"📁 Files saved in: {self.output_dir}")


if __name__ == "__main__":
    preparer = TrainingDataPreparer()
    preparer.prepare_all()

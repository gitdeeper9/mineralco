# 📊 MINERALCO Data Directory Structure

This directory contains all data files for the MINERALCO project.

## 📁 Directory Structure

```

data/
├── raw/                    # Raw data from external sources
│   ├── mindat/            # Data from mindat.org
│   ├── rruff/             # RRUFF database files
│   ├── ams/               # American Mineralogist database
│   └── iris/              # IRIS seismic data
│
├── processed/              # Cleaned and processed data
│   ├── cis_parameters/    # Processed CIS parameters
│   └── pvt_data/          # Cleaned P-V-T data
│
├── databases/              # Curated databases
│   ├── cis/               # Crystal Intelligence Septuplet
│   │   └── cis_database_v1.0.0.json
│   ├── space_groups/      # Space groups (1-230)
│   │   └── space_groups_230.json
│   └── mineral_list/      # Lists of minerals by category
│
├── experimental/           # Experimental measurements
│   ├── dac/               # Diamond Anvil Cell data
│   │   └── combined_dac_data.csv
│   ├── multi_anvil/       # Multi-anvil press data
│   └── shock/             # Shock wave experiments
│
├── reference/              # Reference Earth models
│   ├── prem/              # Preliminary Reference Earth Model
│   │   └── prem_1981_updated.csv
│   ├── ak135/             # AK135 seismic model
│   └── iasp91/            # IASP91 seismic model
│
├── validation/             # Validation datasets
│   ├── phase_transitions/ # Known phase transition P-T conditions
│   └── elastic_constants/ # Elastic constant measurements
│
├── sample/                 # Sample data for tutorials
│   ├── tutorials/         # Tutorial example files
│   └── benchmarks/        # Benchmark examples
│
├── output/                 # Generated output files
│   ├── eos_fits/          # EOS fitting results
│   ├── phase_diagrams/    # Phase diagram images
│   └── reports/           # Generated reports
│
└── cache/                  # Cached data
├── api_responses/     # Cached API responses
└── computed/          # Pre-computed values

```

## 📋 Data Sources

| Source | Description | License | URL |
|--------|-------------|---------|-----|
| **mindat.org** | Mineral database | CC-BY-NC | https://www.mindat.org |
| **RRUFF Project** | Raman spectra & mineral data | Public Domain | https://rruff.info |
| **American Mineralogist** | Crystal structure database | Open | http://rruff.geo.arizona.edu/AMS |
| **IRIS DMC** | Seismic reference models | Open | https://ds.iris.edu/ds/products/emc-prem |
| **Published Literature** | Experimental P-V-T data | Various | Various DOIs |

## 🔍 File Formats

- **JSON**: Structured data (CIS parameters, space groups)
- **CSV**: Tabular data (P-V-T measurements, PREM model)
- **YAML**: Configuration files
- **HDF5**: Large datasets (planned for v2.0)

## 📊 Key Files

| File | Path | Description |
|------|------|-------------|
| `cis_database_v1.0.0.json` | `databases/cis/` | 20+ minerals with CIS parameters |
| `space_groups_230.json` | `databases/space_groups/` | Complete space group data |
| `combined_dac_data.csv` | `experimental/dac/` | 100+ P-V-T data points |
| `prem_1981_updated.csv` | `reference/prem/` | PREM model with depths |

## 📝 Usage Examples

```python
# Load CIS database
import json
with open('data/databases/cis/cis_database_v1.0.0.json') as f:
    data = json.load(f)
    bridgmanite = [m for m in data['minerals'] if m['name'] == 'bridgmanite'][0]
    print(f"K0 = {bridgmanite['K0']} GPa")

# Load experimental data
import pandas as pd
df = pd.read_csv('data/experimental/dac/combined_dac_data.csv', comment='#')
bridgmanite_data = df[df['mineral'] == 'bridgmanite']
```

🔄 Updating Data

To add new data:

1. Place raw files in raw/ with proper attribution
2. Process and clean to processed/
3. Update curated databases in databases/
4. Add validation tests in tests/test_data_loading.py

📜 Citation

When using MINERALCO data, please cite:

```bibtex
@software{baladi2026mineralco,
  author = {Baladi, Samir},
  title = {MINERALCO: Seven Parameters to Decode the Earth's Solid Interior},
  year = {2026},
  doi = {10.5281/zenodo.19009597}
}
```

For individual data sources, please cite the original references.

---

Last updated: 2026-03-14

# 📚 MINERALCO Data Sources

This document tracks the original sources for all data used in MINERALCO.

## 🪨 Mineral Databases

### mindat.org
- **URL**: https://www.mindat.org
- **License**: CC-BY-NC
- **Accessed**: 2026-03-14
- **Data used**: Mineral formulas, crystal systems, space groups, physical properties
- **Minerals**: All 20 minerals in CIS database

### RRUFF Project
- **URL**: https://rruff.info
- **License**: Public Domain
- **Accessed**: 2026-03-14
- **Data used**: Unit cell parameters, Raman spectra (for phonon Grüneisen validation)
- **Website**: http://rruff.info

### American Mineralogist Crystal Structure Database
- **URL**: http://rruff.geo.arizona.edu/AMS
- **License**: Open access
- **Accessed**: 2026-03-14
- **Data used**: Lattice parameters, space groups
- **Reference**: Downs, R.T. & Hall-Wallace, M. (2003)

## 🔬 Experimental Data

### Bridgmanite EOS (MgSiO3)
- **Source**: Fiquet et al. (2000)
- **Journal**: Physics of the Earth and Planetary Interiors
- **DOI**: 10.1016/S0031-9201(00)00167-6
- **Method**: Synchrotron XRD, Diamond Anvil Cell
- **Pressure range**: 0-130 GPa
- **Data points**: 25

### Bridgmanite High-Temperature
- **Source**: Murakami et al. (2012)
- **Journal**: Nature
- **DOI**: 10.1038/nature11004
- **Method**: In-situ XRD, Laser-heated DAC
- **Temperature range**: 300-2000 K
- **Data points**: 12

### Periclase Pressure Standard (MgO)
- **Source**: Tange et al. (2009)
- **Journal**: Journal of Geophysical Research
- **DOI**: 10.1029/2008JB005813
- **Method**: Synchrotron XRD
- **Pressure range**: 0-150 GPa
- **Data points**: 16

### Olivine System (Mg2SiO4)
- **Source**: Katsura et al. (2004)
- **Journal**: Physics of the Earth and Planetary Interiors
- **DOI**: 10.1016/j.pepi.2004.01.006
- **Phases**: Forsterite, Ringwoodite
- **Data points**: 18

### ε-Iron (hcp-Fe)
- **Source**: Tateno et al. (2010)
- **Journal**: Science
- **DOI**: 10.1126/science.1194662
- **Pressure range**: 50-360 GPa
- **Data points**: 8

### Stishovite (SiO2)
- **Source**: Andrault et al. (2003)
- **Journal**: European Journal of Mineralogy
- **DOI**: 10.1127/0935-1221/2003/0015-0501
- **Data points**: 11

## 🌍 Reference Earth Models

### PREM (Preliminary Reference Earth Model)
- **Source**: Dziewonski, A.M. & Anderson, D.L. (1981)
- **Journal**: Physics of the Earth and Planetary Interiors
- **DOI**: 10.1016/0031-9201(81)90046-7
- **Updated**: IRIS DMC (2025)
- **URL**: https://ds.iris.edu/ds/products/emc-prem

## 📊 Summary Statistics

| Category | Sources | Data Points |
|----------|---------|-------------|
| Mineral Databases | 3 | 20 minerals |
| Experimental Studies | 7 | 112 P-V-T points |
| Reference Models | 1 | 102 depth points |
| **Total** | **11** | **434+** |

## 📝 Citation Guidelines

When using data from these sources, please cite:

1. The original publication (DOI provided)
2. MINERALCO framework (DOI: 10.5281/zenodo.19009597)

For multiple sources, a combined citation is acceptable.

---

*Last updated: 2026-03-14*

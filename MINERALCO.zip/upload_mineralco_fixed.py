#!/usr/bin/env python3

"""MINERALCO Upload v1.0.0 - نسخة مصححة"""

import requests
import hashlib
import os
import glob

TOKEN = "pypi-AgEIcHlwaS5vcmcCJDA4YzBiZThiLTk1NzEtNDc3MC1hNTk5LTRiNGYzOTkyYTY1MQACKlszLCJlZjQ3ZDllOS04YmU5LTQ2OWMtYWQ0OC0wODRhZTg4YzZjMTUiXQAABiDrOK5z2H0iMKsMCn5SUMlNPLYh_r7GsGL2t9YPRTZQcA"

print("="*60)
print("💎 MINERALCO v1.0.0 Upload - PyPI (نسخة مصححة)")
print("="*60)

# قراءة README.md
with open('README.md', 'r', encoding='utf-8') as f:
    readme = f.read()
print(f"📄 README.md: {len(readme)} حرف")

# البحث عن ملفات التوزيع
wheel_files = glob.glob("dist/*.whl")
tar_files = glob.glob("dist/*.tar.gz")

print(f"\n📦 الملفات الموجودة:")
for f in wheel_files + tar_files:
    print(f"   • {os.path.basename(f)}")

for filepath in wheel_files + tar_files:
    filename = os.path.basename(filepath)
    print(f"\n📤 رفع: {filename}")

    # تحديد نوع الملف
    if filename.endswith('.tar.gz'):
        filetype = 'sdist'
        pyversion = 'source'
    else:
        filetype = 'bdist_wheel'
        pyversion = 'py3'

    # حساب الهاشات
    with open(filepath, 'rb') as f:
        content = f.read()
    md5_hash = hashlib.md5(content).hexdigest()
    sha256_hash = hashlib.sha256(content).hexdigest()

    # بيانات الرفع - تم تعديل الاسم ليطابق الملفات
    data = {
        ':action': 'file_upload',
        'metadata_version': '2.1',
        'name': 'mineralco',  # تم التعديل من meneralco إلى mineralco
        'version': '1.0.0',
        'filetype': filetype,
        'pyversion': pyversion,
        'md5_digest': md5_hash,
        'sha256_digest': sha256_hash,
        'description': readme,
        'description_content_type': 'text/markdown',
        'author': 'Samir Baladi',
        'author_email': 'gitdeeper@gmail.com',
        'license': 'MIT',
        'summary': 'MINERALCO: Computational Mineralogy, Crystallographic Physics & High-Pressure Phase Dynamics',
        'home_page': 'https://mineralco.netlify.app',
        'requires_python': '>=3.8',
        'keywords': 'mineralogy, crystallography, high-pressure, equation-of-state, grüneisen, debye, birch-murnaghan, phase-transition, mantle, core'
    }

    # رفع الملف
    with open(filepath, 'rb') as f:
        response = requests.post(
            'https://upload.pypi.org/legacy/',
            files={'content': (filename, f, 'application/octet-stream')},
            data=data,
            auth=('__token__', TOKEN),
            timeout=60,
            headers={'User-Agent': 'MINERALCO-Uploader/1.0'}
        )

    print(f"   الحالة: {response.status_code}")

    if response.status_code == 200:
        print("   ✅✅✅ نجاح!")
    else:
        print(f"   ❌ خطأ: {response.text[:200]}")

print("\n" + "="*60)
print("🔗 https://pypi.org/project/mineralco/1.0.0/")
print("="*60)

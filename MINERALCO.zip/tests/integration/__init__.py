"""Integration tests for MINERALCO"""

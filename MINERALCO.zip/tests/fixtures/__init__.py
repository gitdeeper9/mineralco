"""Test fixtures for MINERALCO"""

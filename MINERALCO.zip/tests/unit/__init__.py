"""Unit tests for MINERALCO"""
